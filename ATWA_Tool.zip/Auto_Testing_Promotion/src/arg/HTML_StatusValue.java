package arg;

public class HTML_StatusValue {
	public static final String EMPTY = "null";
	public static final String DEFAULT = "o";
	public static final String IGNORE = "_";
}
