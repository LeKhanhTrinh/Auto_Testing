package arg;

public class Webdriver_getType {
	public static final String ATT_VALUE="value";
	//public static final String text="";

}
