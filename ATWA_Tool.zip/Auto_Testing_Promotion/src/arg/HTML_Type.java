package arg;

public class HTML_Type {
	public static final String TEXTBOX="textbox";
	public static final String TEXTAREA="textarea";
	public static final String BUTTON="btn";
	public static final String TITLE="title";
	public static final String CHECKBOX="cbox";
	public static final String TEXTHTML="texthtml";
	public static final String RADIO="radio";
	public static final String LISTBOX="listbox";
}
