package arg;

public class Webdriver_actionType {

	public static final String CLICK = "click";
	public static final String ADDTEXT = "addtext";
	public static final String DELTEXT = "deltext";
	public static final String SELECT = "select";
}
